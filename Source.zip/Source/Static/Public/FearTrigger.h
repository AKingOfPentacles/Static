﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "FearTrigger.generated.h"

UCLASS()
class STATIC_API AFearTrigger : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AFearTrigger();

protected:
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Trigger fear on nearby living players
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Fear")
	void TriggerFear();

private:
	// The radius of the fear trigger
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Fear")
	float FearRadius;

	// The amount to raise cardiac rhythm when triggered
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Fear")
	float RhythmRaiseAmount;
};
