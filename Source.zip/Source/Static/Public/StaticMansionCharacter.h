﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "CardiacRhythmComponent.h"
#include "InventoryComponent.h"
#include "StaticMansionCharacter.generated.h"

UCLASS()
class STATIC_API AStaticMansionCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AStaticMansionCharacter();

protected:
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	// Get the cardiac rhythm component
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Character")
	UCardiacRhythmComponent* GetCardiacRhythmComponent() const { return CardiacRhythmComponent; }

	// Get the inventory component
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Character")
	UInventoryComponent* GetInventoryComponent() const { return InventoryComponent; }

private:
	// The cardiac rhythm component
	UPROPERTY(VisibleAnywhere, Category = "Static Mansion|Character")
	UCardiacRhythmComponent* CardiacRhythmComponent;

	// The inventory component
	UPROPERTY(VisibleAnywhere,Category = "Static Mansion|Character")
	UInventoryComponent* InventoryComponent;
};
