﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ItemBase.h"
#include "InventoryComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnInventoryChanged);

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class STATIC_API UInventoryComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UInventoryComponent();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	// Add an item to the inventory
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Inventory")
	void AddItem(AItemBase* Item);

	// Remove an item from the inventory
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Inventory")
	void RemoveItem(AItemBase* Item);

	// Use a specific item
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Inventory")
	void UseItem(EItemType ItemType);

	// Check if inventory has an item of a certain type
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Inventory")
	bool HasItem(EItemType ItemType) const;

	// Get the number of items of a specific type
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Inventory")
	int32 GetItemCount(EItemType ItemType) const;

	// Event broadcast when inventory changes
	UPROPERTY(BlueprintAssignable, Category = "Static Mansion|Inventory")
	FOnInventoryChanged OnInventoryChanged;

private:
	// The inventory items
	UPROPERTY(Replicated)
	TArray<AItemBase*> InventoryItems;

	// Maximum inventory size
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Inventory")
	int32 MaxInventorySize;
};
