﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "StaticMansionCharacter.h"
#include "LivingCharacter.generated.h"

UCLASS()
class STATIC_API ALivingCharacter : public AStaticMansionCharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ALivingCharacter();

protected:
	virtual void BeginPlay() override;
	
	virtual void GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

private:
	// Whether the player is currently using an item
	UPROPERTY(Replicated)
	bool bIsUsingItem;

	// The current flashlight component (if equipped)
	UPROPERTY(VisibleAnywhere, Category = "Static Mansion|Living")
	class UFlashlightComponent* FlashlightComponent;
};
