﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CardiacRhythmComponent.generated.h"

// Delegate for cardiac rhythm changes
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCardiacRhythmChanged, float, NewRhythm);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnHeartPainEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnFleeEvent);

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class STATIC_API UCardiacRhythmComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UCardiacRhythmComponent();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	// Get current cardiac rhythm value (0.0 to 1.0)
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Cardiac Rhythm")
	float GetCurrentRhythm() const { return CurrentRhythm; }

	// Get current fear level (0.0 to 1.0)
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Cardiac Rhythm")
	float GetFearLevel() const { return FearLevel; }

	// Raise the cardiac rhythm due to a scare event
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Cardiac Rhythm")
	void RaiseRhythm(float Amount);

	// Trigger a heart pain event (indicates stress)
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Cardiac Rhythm")
	void TriggerHeartPain();

	// Check if player is about to flee due to fear
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Cardiac Rhythm")
	bool ShouldFlee() const { return HeartPainCount >= 3; }

	// Event broadcast when cardiac rhythm changes
	UPROPERTY(BlueprintAssignable, Category = "Static Mansion|Cardiac Rhythm")
	FOnCardiacRhythmChanged OnCardiacRhythmChanged;

	// Event broadcast when heart pain occurs
	UPROPERTY(BlueprintAssignable, Category = "Static Mansion|Cardiac Rhythm")
	FOnHeartPainEvent OnHeartPain;

	// Event broadcast when player flees
	UPROPERTY(BlueprintAssignable, Category = "Static Mansion|Cardiac Rhythm")
	FOnFleeEvent OnFlee;

private:
	// Current cardiac rhythm value (0.0 to 1.0)
	UPROPERTY(Replicated)
	float CurrentRhythm;

	// Fear level based on rhythm (0.0 to 1.0)
	UPROPERTY(Replicated)
	float FearLevel;

	// Number of heart pain events
	UPROPERTY(Replicated)
	int32 HeartPainCount;

	// Decay rate for cardiac rhythm (per second)
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Cardiac Rhythm")
	float RhythmDecayRate;

	// Threshold for triggering heart pain
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Cardiac Rhythm")
	float HeartPainThreshold;

	// Time between heart pain events (to prevent spam)
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Cardiac Rhythm")
	float HeartPainCooldown;

	// Timer handle for heart pain cooldown
	FTimerHandle HeartPainTimerHandle;

	// Internal method to decay rhythm over time
	void DecayRhythm(float DeltaTime);

	// Internal method to handle fleeing logic
	void HandleFleeLogic();
	
	// Timer callback for phase countdown
	void OnPhaseTimeExpired();
};
