﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ItemBase.generated.h"

UENUM(BlueprintType)
enum class EItemType : uint8
{
	Match			UMETA(DisplayName = "Match"),
	Sage			UMETA(DisplayName = "Sage"),
	Salt			UMETA(DisplayName = "Salt"),
	Chalk			UMETA(DisplayName = "Chalk"),
	Flashlight		UMETA(DisplayName = "Flashlight"),
	OccultItem		UMETA(DisplayName = "Occult Item"),
	Bones			UMETA(DisplayName = "Bones")
};

UCLASS()
class STATIC_API AItemBase : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AItemBase();

protected:
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Get the item type
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Item")
	EItemType GetItemType() const { return ItemType; }

	// Use the item (implemented by subclasses)
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Item")
	virtual void UseItem();

	// Get item name for UI display
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Item")
	FText GetItemName() const { return ItemName; }

protected:
	// The type of item
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Static Mansion|Item")
	EItemType ItemType;

	// Display name for the item
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Static Mansion|Item")
	FText ItemName;

	// Whether this item can be picked up
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Static Mansion|Item")
	bool bCanPickup;
};
