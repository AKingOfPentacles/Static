﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "FlashlightComponent.generated.h"

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class STATIC_API UFlashlightComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UFlashlightComponent();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	// Turn the flashlight on or off
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Flashlight")
	void ToggleFlashlight();

	// Check if flashlight is currently on
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Flashlight")
	bool IsOn() const { return bIsOn; }

	// Consume battery for flashlight usage
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Flashlight")
	void ConsumeBattery(float Amount);

	// Get current battery level (0.0 to 1.0)
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Flashlight")
	float GetBatteryLevel() const { return BatteryLevel; }

private:
	// Whether the flashlight is currently on
	UPROPERTY(Replicated)
	bool bIsOn;

	// Current battery level (0.0 to 1.0)
	UPROPERTY(Replicated)
	float BatteryLevel;

	// Maximum battery level
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Flashlight")
	float MaxBatteryLevel;

	// Battery consumption rate per second when on
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Flashlight")
	float BatteryConsumptionRate;

	// Light component for the flashlight
	UPROPERTY(VisibleDefaultsOnly, Category = "Static Mansion|Flashlight")
	class UPointLightComponent* FlashlightLight;
};
