﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ItemBase.h"
#include "WardSystem.generated.h"

UCLASS()
class STATIC_API AWardSystem : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AWardSystem();

protected:
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Create a ward boundary using salt or chalk
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Ward")
	void CreateWard(EItemType NewWardType, FVector Location, FRotator Rotation);

	// Remove a ward
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Ward")
	void RemoveWard();

	// Check if a point is inside the ward
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Ward")
	bool IsPointInWard(FVector Point) const;

	// The type of ward
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Static Mansion|Ward")
	EItemType WardType;

private:

	// Visual representation of the ward
	UPROPERTY(VisibleDefaultsOnly, Category = "Static Mansion|Ward")
	class UStaticMeshComponent* WardVisual;

	// Boundary of the ward (used for collision detection)
	UPROPERTY(VisibleDefaultsOnly, Category = "Static Mansion|Ward")
	class USphereComponent* WardBoundary;
};
