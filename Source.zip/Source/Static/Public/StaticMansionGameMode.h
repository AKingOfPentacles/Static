﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GamePhaseManager.h"
#include "StaticMansionGameMode.generated.h"

UCLASS()
class STATIC_API AStaticMansionGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AStaticMansionGameMode();

protected:
	virtual void BeginPlay() override;

public:	
	// Get the game phase manager
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Game Mode")
	AGamePhaseManager* GetGamePhaseManager() const { return GamePhaseManager; }

private:
	// The game phase manager that controls the three phases
	UPROPERTY(VisibleAnywhere,Category = "Static Mansion|Game Mode")
	AGamePhaseManager* GamePhaseManager;
};
