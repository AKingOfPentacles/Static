﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "GamePhaseManager.generated.h"

// Enum for game phases
UENUM(BlueprintType)
enum class EGamePhase : uint8
{
	Exploration		UMETA(DisplayName = "Exploration"),
	Protection		UMETA(DisplayName = "Protection"),
	Confrontation	UMETA(DisplayName = "Confrontation")
};

// Delegate for phase change events
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPhaseChanged, EGamePhase, NewPhase);

UCLASS()
class STATIC_API AGamePhaseManager : public AGameStateBase
{
	GENERATED_BODY()

public:
	AGamePhaseManager();

	// Get the current game phase
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Game Phase")
	EGamePhase GetCurrentPhase() const { return CurrentPhase; }

	// Get the time remaining in the current phase (in seconds)
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Game Phase")
	float GetTimeRemainingInPhase() const { return TimeRemainingInPhase; }

	// Get the total duration of a specific phase (in seconds)
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Game Phase")
	float GetPhaseDuration(EGamePhase Phase) const;

	// Start the game and initialize phases
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Game Phase")
	void StartGame();

	// Force transition to a new phase (for testing or special events)
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Game Phase")
	void ForcePhaseTransition(EGamePhase NewPhase);

	// Event broadcast when phase changes
	UPROPERTY(BlueprintAssignable, Category = "Static Mansion|Game Phase")
	FOnPhaseChanged OnPhaseChanged;

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

private:
	// Current game phase
	UPROPERTY(Replicated)
	EGamePhase CurrentPhase;

	// Time remaining in the current phase (in seconds)
	UPROPERTY(Replicated)
	float TimeRemainingInPhase;

	// Phase durations in seconds (can be configured per game instance)
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Game Phase")
	float ExplorationDuration;

	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Game Phase")
	float ProtectionDuration;

	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Game Phase")
	float ConfrontationDuration;

	// Timer handle for phase transitions
	FTimerHandle PhaseTimerHandle;

	// Initialize the first phase
	void InitializeFirstPhase();

	// Handle phase transition
	void TransitionToNextPhase();

	// Timer callback for phase countdown
	void OnPhaseTimeExpired();
};
