﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "SpecterEnergyComponent.generated.h"

// Delegate for energy changes
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSpecterEnergyChanged, float, NewEnergy);

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class STATIC_API USpecterEnergyComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	USpecterEnergyComponent();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	// Get current specter energy value (0.0 to 1.0)
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Specter Energy")
	float GetCurrentEnergy() const { return CurrentEnergy; }

	// Get maximum energy value
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Specter Energy")
	float GetMaxEnergy() const { return MaxEnergy; }

	// Consume energy for an ability
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Specter Energy")
	bool ConsumeEnergy(float Amount);

	// Refill energy (e.g., when collecting memorabilia)
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Specter Energy")
	void RefillEnergy(float Amount);

	// Lose energy due to living defenses
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Specter Energy")
	void LoseEnergy(float Amount);

	// Event broadcast when energy changes
	UPROPERTY(BlueprintAssignable, Category = "Static Mansion|Specter Energy")
	FOnSpecterEnergyChanged OnEnergyChanged;

private:
	// Current specter energy value (0.0 to 1.0)
	UPROPERTY(Replicated)
	float CurrentEnergy;

	// Maximum energy value
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Specter Energy")
	float MaxEnergy;

	// Energy regeneration rate per second
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Specter Energy")
	float EnergyRegenRate;

	// Energy cost for abilities (per second)
	UPROPERTY(EditDefaultsOnly, Category = "Static Mansion|Specter Energy")
	float AbilityCostPerSecond;

	// Timer handle for energy regeneration
	FTimerHandle EnergyRegenTimerHandle;
};
