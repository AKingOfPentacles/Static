﻿// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "StaticMansionCharacter.h"
#include "DeadCharacter.generated.h"

UCLASS()
class STATIC_API ADeadCharacter : public AStaticMansionCharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ADeadCharacter();

protected:
	virtual void BeginPlay() override;
	
	virtual void GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	// Toggle pass-through wall mode
	UFUNCTION(BlueprintCallable, Category = "Static Mansion|Dead")
	void TogglePassThroughWalls();

	// Check if the dead character is currently passing through walls
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Dead")
	bool IsPassingThroughWalls() const { return bIsPassingThroughWalls; }
	
	// Get SpecterEnergyComponent
	UFUNCTION(BlueprintPure, Category = "Static Mansion|Character")
	USpecterEnergyComponent* GetSpecterEnergyComponent() const { return SpecterEnergyComponent; }

private:
	// Whether this dead character is currently passing through walls
	UPROPERTY(Replicated)
	bool bIsPassingThroughWalls;

	// The specter energy component for the dead player
	UPROPERTY(VisibleAnywhere, Category = "Static Mansion|Dead")
	USpecterEnergyComponent* SpecterEnergyComponent;
};
