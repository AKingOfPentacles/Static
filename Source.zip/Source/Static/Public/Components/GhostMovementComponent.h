﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GhostMovementComponent.generated.h"

// ─────────────────────────────────────────────────────────────────────────────
// UGhostMovementComponent
//
//   Replaces UCharacterMovementComponent on ADeadCharacter.
//   Keeps the Dead character in MOVE_Flying at all times — no gravity,
//   free 3D movement, gentle downward drift when idle.
//
//   Pass-through is NO LONGER handled here.
//   The Dead pass through doors specifically via ADoorActor::PassThrough(),
//   which temporarily disables the capsule collision for 0.5s.
//   This is simpler, more reliable, and more narratively interesting.
//
//   EDITOR SETUP:
//   You won't see this in the Add Component list — it replaces the default
//   movement component slot. Tune SpectralSpeed and GravitationalDrift
//   in BP_DeadCharacter's Details panel under CharacterMovementComponent.
// ─────────────────────────────────────────────────────────────────────────────
UCLASS()
class STATIC_API UGhostMovementComponent : public UCharacterMovementComponent
{
    GENERATED_BODY()

public:
    UGhostMovementComponent();

    virtual void BeginPlay() override;
    virtual void PhysFlying(float DeltaTime, int32 Iterations) override;

    // ── Tuning ────────────────────────────────────────────────────────────────

    /** Normal spectral float speed (cm/s). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ghost Movement",
        meta = (ClampMin = "100.0"))
    float SpectralSpeed = 500.0f;

    /**
     * Downward drift force when the specter is not actively moving up (cm/s²).
     * Keeps them near floor level without full gravity.
     * 0 = freely floating. 200 = stays close to the ground.
     */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ghost Movement",
        meta = (ClampMin = "0.0"))
    float GravitationalDrift = 120.0f;
};