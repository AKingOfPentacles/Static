﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "StaticMansionCharacter.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values
AStaticMansionCharacter::AStaticMansionCharacter()
{
	// Set this character to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryActorTick.bCanEverTick = true;

	// Create components
	CardiacRhythmComponent = CreateDefaultSubobject<UCardiacRhythmComponent>(TEXT("CardiacRhythm"));
	InventoryComponent = CreateDefaultSubobject<UInventoryComponent>(TEXT("Inventory"));

	// Set up collision
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);
}

void AStaticMansionCharacter::BeginPlay()
{
	Super::BeginPlay();
	
}

void AStaticMansionCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AStaticMansionCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}
