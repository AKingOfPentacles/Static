﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "StaticMansionGameMode.h"
#include "GamePhaseManager.h"

AStaticMansionGameMode::AStaticMansionGameMode()
{
	// Set default values for the game mode
	GamePhaseManager = nullptr;
}

void AStaticMansionGameMode::BeginPlay()
{
	Super::BeginPlay();
	
	// Spawn and initialize the game phase manager
	if (!GamePhaseManager)
	{
		GamePhaseManager = GetWorld()->SpawnActor<AGamePhaseManager>(AGamePhaseManager::StaticClass());
		if (GamePhaseManager)
		{
			GamePhaseManager->StartGame();
		}
	}
}
