﻿#include "Components/GhostMovementComponent.h"

UGhostMovementComponent::UGhostMovementComponent()
{
    // No gravity — ghosts float.
    GravityScale        = 0.0f;
    MaxFlySpeed         = SpectralSpeed;
    MaxAcceleration     = 1200.0f;
    BrakingDecelerationFlying = 800.0f;
}

void UGhostMovementComponent::BeginPlay()
{
    Super::BeginPlay();

    // Start immediately in flying mode.
    SetMovementMode(MOVE_Flying);
    MaxFlySpeed = SpectralSpeed;
}

// ─────────────────────────────────────────────────────────────────────────────
// PhysFlying — override to add gentle downward drift
//   Called every frame while in MOVE_Flying.
//   We let the base class handle acceleration and braking, then nudge
//   velocity downward if the specter isn't actively moving up.
// ─────────────────────────────────────────────────────────────────────────────

void UGhostMovementComponent::PhysFlying(float DeltaTime, int32 Iterations)
{
    // Apply drift before the base class moves the character.
    // Only drift down when there's no upward input.
    if (Velocity.Z > -GravitationalDrift)
    {
        const FVector PendingInput = GetPendingInputVector();
        const bool bMovingUp = PendingInput.Z > 0.1f;

        if (!bMovingUp)
        {
            Velocity.Z = FMath::Max(
                Velocity.Z - GravitationalDrift * DeltaTime,
                -GravitationalDrift);
        }
    }

    Super::PhysFlying(DeltaTime, Iterations);
}