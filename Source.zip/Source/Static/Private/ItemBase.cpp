﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "ItemBase.h"
#include "Net/UnrealNetwork.h"

// Sets default values
AItemBase::AItemBase()
{
	// Set this actor to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryActorTick.bCanEverTick = false;

	// Default values
	bCanPickup = true;
}

void AItemBase::BeginPlay()
{
	Super::BeginPlay();
	
}

void AItemBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AItemBase::UseItem()
{
	// Base implementation does nothing - this is meant to be overridden
}
