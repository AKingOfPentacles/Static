﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "FlashlightComponent.h"
#include "Components/PointLightComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values for this component's properties
UFlashlightComponent::UFlashlightComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// Default values
	bIsOn = false;
	BatteryLevel = 1.0f;
	MaxBatteryLevel = 1.0f;
	BatteryConsumptionRate = 0.1f; // Consume 10% battery per second when on
}

void UFlashlightComponent::BeginPlay()
{
	Super::BeginPlay();
	
	// Create a point light for the flashlight effect
	FlashlightLight = CreateDefaultSubobject<UPointLightComponent>(TEXT("FlashlightLight"));
	FlashlightLight->AttachToComponent(GetOwner()->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
	FlashlightLight->SetIntensity(0.0f); // Start off
}

void UFlashlightComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UFlashlightComponent, bIsOn);
	DOREPLIFETIME(UFlashlightComponent, BatteryLevel);
}

void UFlashlightComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// Consume battery if flashlight is on
	if (bIsOn && BatteryLevel > 0.0f)
	{
		BatteryLevel = FMath::Max(0.0f, BatteryLevel - BatteryConsumptionRate * DeltaTime);
		
		// Update light intensity based on battery level
		if (FlashlightLight)
		{
			FlashlightLight->SetIntensity(BatteryLevel * 1000.0f); // Scale up for visibility
		}
	}
}

void UFlashlightComponent::ToggleFlashlight()
{
	bIsOn = !bIsOn;
	
	// Update light intensity
	if (FlashlightLight)
	{
		FlashlightLight->SetIntensity(bIsOn ? BatteryLevel * 1000.0f : 0.0f);
	}
}

void UFlashlightComponent::ConsumeBattery(float Amount)
{
	BatteryLevel = FMath::Max(0.0f, BatteryLevel - Amount);
}
