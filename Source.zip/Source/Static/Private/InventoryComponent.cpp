﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "InventoryComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values for this component's properties
UInventoryComponent::UInventoryComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;

	// Default values
	MaxInventorySize = 10;
}

void UInventoryComponent::BeginPlay()
{
	Super::BeginPlay();
	
}

void UInventoryComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UInventoryComponent, InventoryItems);
}

void UInventoryComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UInventoryComponent::AddItem(AItemBase* Item)
{
	if (!Item || InventoryItems.Num() >= MaxInventorySize)
		return;

	InventoryItems.Add(Item);
	OnInventoryChanged.Broadcast();
}

void UInventoryComponent::RemoveItem(AItemBase* Item)
{
	if (!Item)
		return;

	InventoryItems.RemoveSingle(Item);
	OnInventoryChanged.Broadcast();
}

void UInventoryComponent::UseItem(EItemType ItemType)
{
	for (int32 i = 0; i < InventoryItems.Num(); ++i)
	{
		if (InventoryItems[i] && InventoryItems[i]->GetItemType() == ItemType)
		{
			InventoryItems[i]->UseItem();
			break;
		}
	}
}

bool UInventoryComponent::HasItem(EItemType ItemType) const
{
	for (const AItemBase* Item : InventoryItems)
	{
		if (Item && Item->GetItemType() == ItemType)
			return true;
	}
	return false;
}

int32 UInventoryComponent::GetItemCount(EItemType ItemType) const
{
	int32 Count = 0;
	for (const AItemBase* Item : InventoryItems)
	{
		if (Item && Item->GetItemType() == ItemType)
			Count++;
	}
	return Count;
}
