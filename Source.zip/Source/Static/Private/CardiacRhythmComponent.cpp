﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "CardiacRhythmComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values for this component's properties
UCardiacRhythmComponent::UCardiacRhythmComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// Default values
	CurrentRhythm = 0.0f;
	FearLevel = 0.0f;
	HeartPainCount = 0;
	RhythmDecayRate = 0.2f; // Decay rate per second
	HeartPainThreshold = 0.8f;
	HeartPainCooldown = 1.0f;
}

void UCardiacRhythmComponent::BeginPlay()
{
	Super::BeginPlay();

	// Initialize the fear level
	FearLevel = CurrentRhythm;
}

void UCardiacRhythmComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UCardiacRhythmComponent, CurrentRhythm);
	DOREPLIFETIME(UCardiacRhythmComponent, FearLevel);
	DOREPLIFETIME(UCardiacRhythmComponent, HeartPainCount);
}

void UCardiacRhythmComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// Decay the rhythm over time when not under stress
	DecayRhythm(DeltaTime);
}

void UCardiacRhythmComponent::RaiseRhythm(float Amount)
{
	if (Amount <= 0.0f) return;

	CurrentRhythm = FMath::Min(1.0f, CurrentRhythm + Amount);
	FearLevel = CurrentRhythm;
	
	// Broadcast rhythm change
	OnCardiacRhythmChanged.Broadcast(CurrentRhythm);

	// Check if we should trigger heart pain
	if (CurrentRhythm >= HeartPainThreshold)
	{
		TriggerHeartPain();
	}
}

void UCardiacRhythmComponent::TriggerHeartPain()
{
	// Prevent spamming heart pain events
	if (GetWorld() && HeartPainTimerHandle.IsValid())
	{
		return;
	}

	// Increment heart pain count
	HeartPainCount++;

	// Broadcast the heart pain event
	OnHeartPain.Broadcast();

	// Handle fleeing logic if we've had 3 heart pains
	HandleFleeLogic();

	// Set a cooldown timer to prevent spam
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().SetTimer(HeartPainTimerHandle, this, &UCardiacRhythmComponent::OnPhaseTimeExpired, HeartPainCooldown, false);
	}
}

void UCardiacRhythmComponent::DecayRhythm(float DeltaTime)
{
	if (CurrentRhythm > 0.0f)
	{
		CurrentRhythm = FMath::Max(0.0f, CurrentRhythm - RhythmDecayRate * DeltaTime);
		FearLevel = CurrentRhythm;
		
		// Broadcast rhythm change if it changed
		OnCardiacRhythmChanged.Broadcast(CurrentRhythm);
	}
}

void UCardiacRhythmComponent::HandleFleeLogic()
{
	if (HeartPainCount >= 3)
	{
		// Trigger flee event
		OnFlee.Broadcast();
	}
}

void UCardiacRhythmComponent::OnPhaseTimeExpired()
{
	// Clear the heart pain cooldown timer
	if (GetWorld() && HeartPainTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(HeartPainTimerHandle);
	}
}
