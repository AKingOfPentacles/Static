﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "DeadCharacter.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values
ADeadCharacter::ADeadCharacter()
{
	// Set this character to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryActorTick.bCanEverTick = true;

	bIsPassingThroughWalls = false;
}

void ADeadCharacter::BeginPlay()
{
	Super::BeginPlay();
	
}

void ADeadCharacter::GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
}

void ADeadCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ADeadCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void ADeadCharacter::TogglePassThroughWalls()
{
	bIsPassingThroughWalls = !bIsPassingThroughWalls;
	
	// Update collision settings
	if (GetCharacterMovement())
	{
		GetCharacterMovement()->SetWalkableFloorZ(bIsPassingThroughWalls ? 0.0f : 0.7f);
	}
}
