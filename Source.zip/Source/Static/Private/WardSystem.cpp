﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "WardSystem.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"

// Sets default values
AWardSystem::AWardSystem()
{
	// Set this actor to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryActorTick.bCanEverTick = true;

	// Create default components
	WardVisual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("WardVisual"));
	SetRootComponent(WardVisual);

	WardBoundary = CreateDefaultSubobject<USphereComponent>(TEXT("WardBoundary"));
	WardBoundary->SetupAttachment(RootComponent);
	WardBoundary->SetCollisionProfileName(TEXT("OverlapAll"));
}

void AWardSystem::BeginPlay()
{
	Super::BeginPlay();
	
}

void AWardSystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AWardSystem::CreateWard(EItemType NewWardType, FVector Location, FRotator Rotation)
{
	// Set ward type
	WardType = NewWardType;

	// Set location and rotation
	SetActorLocation(Location);
	SetActorRotation(Rotation);

	// Visual representation could be set here based on ward type
	// For now, we just use a default sphere component as boundary
}

void AWardSystem::RemoveWard()
{
	Destroy();
}

bool AWardSystem::IsPointInWard(FVector Point) const
{
	if (WardBoundary)
	{
		float Radius = WardBoundary->GetScaledSphereRadius();
		float DistanceSq = FVector::DistSquared(Point, WardBoundary->GetComponentLocation());
		return DistanceSq <= (Radius * Radius);
	}
	return false;
}
