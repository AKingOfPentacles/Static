﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "SpecterEnergyComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values for this component's properties
USpecterEnergyComponent::USpecterEnergyComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// Default values
	CurrentEnergy = 1.0f;
	MaxEnergy = 1.0f;
	EnergyRegenRate = 0.1f; // Regenerate 10% per second
	AbilityCostPerSecond = 0.2f; // Cost 20% per second of ability use
}

void USpecterEnergyComponent::BeginPlay()
{
	Super::BeginPlay();

	// Energy regeneration is handled in TickComponent
}

void USpecterEnergyComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(USpecterEnergyComponent, CurrentEnergy);
}

void USpecterEnergyComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// Regenerate energy over time
	if (CurrentEnergy < MaxEnergy)
	{
		CurrentEnergy = FMath::Min(MaxEnergy, CurrentEnergy + EnergyRegenRate * DeltaTime);
		
		// Broadcast energy change if it changed
		OnEnergyChanged.Broadcast(CurrentEnergy);
	}
}

bool USpecterEnergyComponent::ConsumeEnergy(float Amount)
{
	if (CurrentEnergy >= Amount)
	{
		CurrentEnergy -= Amount;
		OnEnergyChanged.Broadcast(CurrentEnergy);
		return true;
	}
	
	return false;
}

void USpecterEnergyComponent::RefillEnergy(float Amount)
{
	CurrentEnergy = FMath::Min(MaxEnergy, CurrentEnergy + Amount);
	OnEnergyChanged.Broadcast(CurrentEnergy);
}

void USpecterEnergyComponent::LoseEnergy(float Amount)
{
	CurrentEnergy = FMath::Max(0.0f, CurrentEnergy - Amount);
	OnEnergyChanged.Broadcast(CurrentEnergy);
}
