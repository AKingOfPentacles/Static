﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "GamePhaseManager.h"
#include "Net/UnrealNetwork.h"
#include "Kismet/GameplayStatics.h"

AGamePhaseManager::AGamePhaseManager()
{
	// Set default phase durations (in seconds)
	ExplorationDuration = 1800.f;   // 30 minutes
	ProtectionDuration = 1800.f;    // 30 minutes  
	ConfrontationDuration = 1800.f; // 30 minutes

	// Set as server authoritative
	bReplicates = true;
	bAlwaysRelevant = true;
}

void AGamePhaseManager::BeginPlay()
{
	Super::BeginPlay();
	
	// Initialize the game phases
	InitializeFirstPhase();
}

void AGamePhaseManager::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(AGamePhaseManager, CurrentPhase);
	DOREPLIFETIME(AGamePhaseManager, TimeRemainingInPhase);
}

void AGamePhaseManager::InitializeFirstPhase()
{
	// Start with exploration phase
	CurrentPhase = EGamePhase::Exploration;
	TimeRemainingInPhase = ExplorationDuration;

	// Start the timer for this phase
	GetWorld()->GetTimerManager().SetTimer(PhaseTimerHandle, this, &AGamePhaseManager::OnPhaseTimeExpired, TimeRemainingInPhase, false);
	
	// Broadcast the initial phase change
	OnPhaseChanged.Broadcast(CurrentPhase);
}

void AGamePhaseManager::StartGame()
{
	// This is called from GameMode when the game officially starts
	InitializeFirstPhase();
}

void AGamePhaseManager::ForcePhaseTransition(EGamePhase NewPhase)
{
	// Cancel current timer
	if (GetWorld() && PhaseTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(PhaseTimerHandle);
	}

	// Set new phase
	CurrentPhase = NewPhase;
	
	// Set time remaining based on phase duration
	switch (NewPhase)
	{
	case EGamePhase::Exploration:
		TimeRemainingInPhase = ExplorationDuration;
		break;
	case EGamePhase::Protection:
		TimeRemainingInPhase = ProtectionDuration;
		break;
	case EGamePhase::Confrontation:
		TimeRemainingInPhase = ConfrontationDuration;
		break;
	default:
		TimeRemainingInPhase = 0.f;
		break;
	}

	// Start timer for new phase
	GetWorld()->GetTimerManager().SetTimer(PhaseTimerHandle, this, &AGamePhaseManager::OnPhaseTimeExpired, TimeRemainingInPhase, false);
	
	// Broadcast the phase change
	OnPhaseChanged.Broadcast(CurrentPhase);
}

void AGamePhaseManager::TransitionToNextPhase()
{
	// Determine next phase based on current phase
	EGamePhase NextPhase = EGamePhase::Exploration;
	
	switch (CurrentPhase)
	{
	case EGamePhase::Exploration:
		NextPhase = EGamePhase::Protection;
		break;
	case EGamePhase::Protection:
		NextPhase = EGamePhase::Confrontation;
		break;
	case EGamePhase::Confrontation:
		// Game over - no next phase
		return;
	default:
		NextPhase = EGamePhase::Exploration;
		break;
	}

	// Set new phase
	CurrentPhase = NextPhase;
	
	// Set time remaining based on phase duration
	switch (NextPhase)
	{
	case EGamePhase::Exploration:
		TimeRemainingInPhase = ExplorationDuration;
		break;
	case EGamePhase::Protection:
		TimeRemainingInPhase = ProtectionDuration;
		break;
	case EGamePhase::Confrontation:
		TimeRemainingInPhase = ConfrontationDuration;
		break;
	default:
		TimeRemainingInPhase = 0.f;
		break;
	}

	// Start timer for new phase
	GetWorld()->GetTimerManager().SetTimer(PhaseTimerHandle, this, &AGamePhaseManager::OnPhaseTimeExpired, TimeRemainingInPhase, false);
	
	// Broadcast the phase change
	OnPhaseChanged.Broadcast(CurrentPhase);
}

void AGamePhaseManager::OnPhaseTimeExpired()
{
	// Transition to next phase when time expires
	TransitionToNextPhase();
}

float AGamePhaseManager::GetPhaseDuration(EGamePhase Phase) const
{
	switch (Phase)
	{
	case EGamePhase::Exploration:
		return ExplorationDuration;
	case EGamePhase::Protection:
		return ProtectionDuration;
	case EGamePhase::Confrontation:
		return ConfrontationDuration;
	default:
		return 0.f;
	}
}
