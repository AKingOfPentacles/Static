﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "FearTrigger.h"
#include "Components/SphereComponent.h"
#include "StaticMansionCharacter.h"
#include "CardiacRhythmComponent.h"

// Sets default values
AFearTrigger::AFearTrigger()
{
	// Set this actor to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryActorTick.bCanEverTick = false;

	// Create default components
	FearRadius = 500.0f;
	RhythmRaiseAmount = 0.2f;
}

void AFearTrigger::BeginPlay()
{
	Super::BeginPlay();
	
}

void AFearTrigger::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AFearTrigger::TriggerFear()
{
	// Find all living characters in the fear radius
	TArray<AActor*> OverlappingActors;
	GetOverlappingActors(OverlappingActors, AStaticMansionCharacter::StaticClass());
	
	for (AActor* Actor : OverlappingActors)
	{
		AStaticMansionCharacter* Character = Cast<AStaticMansionCharacter>(Actor);
		if (Character && Character->GetCardiacRhythmComponent())
		{
			Character->GetCardiacRhythmComponent()->RaiseRhythm(RhythmRaiseAmount);
		}
	}
}
