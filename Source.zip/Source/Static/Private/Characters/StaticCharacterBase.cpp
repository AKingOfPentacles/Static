﻿#include "Characters/StaticCharacterBase.h"

AStaticCharacterBase::AStaticCharacterBase()
{
	// AAlsCharacter sets up everything for movement and animation.
	// Nothing extra needed here yet.
}