﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "LivingCharacter.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values
ALivingCharacter::ALivingCharacter()
{
	// Set this character to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryActorTick.bCanEverTick = true;

	// Set default values for the flashlight
	bIsUsingItem = false;
}

void ALivingCharacter::BeginPlay()
{
	Super::BeginPlay();
	
}

void ALivingCharacter::GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
}

void ALivingCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ALivingCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}
